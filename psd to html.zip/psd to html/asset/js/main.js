
$(document).ready(function(){
	$(".about-info").click(function(){
	$(".about-infoa").hide(1000);
	});
	$(".about-info").click(function(){
	$(".about-infob").hide(1000);
	});


	$(".about-info").dblclick(function(){
	$(".about-infoa").show(1000);
	});
	$(".about-info").dblclick(function(){
	$(".about-infob").show(1000);
	});


	$(".about-infoa").click(function(){
	$(".about-info").hide(1000);
	});
	$(".about-infoa").click(function(){
	$(".about-infob").hide(1000);
	});



	$(".about-infoa").dblclick(function(){
	$(".about-info").show(1000);
	});
	$(".about-infoa").dblclick(function(){
	$(".about-infob").show(1000);
	});


	// $(".about-infob").click(function(){
	// $("h2").css("color","red");
	// });
	// $(".about-infob").click(function(){
	// $("h1").css("color","yellow");
	// });

	$(".about-infob").click(function(){
		$("h1").css("color","yellow");
		$("h2").css("color","red");
	});
	
})